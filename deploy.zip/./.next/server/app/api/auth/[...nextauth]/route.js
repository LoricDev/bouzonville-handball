var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[externals]_next_dist_38eabf1b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__17d830a0._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_[___nextauth]_route_actions_1c865db8.js")
R.m(59061)
module.exports=R.m(59061).exports
